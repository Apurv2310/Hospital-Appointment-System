
export const HOST_NAME = "localhost";
export const USER_NAME = "root";
export const PASSWORD = "apurv@cdac";
export const SCHEMA = "HOSPITAL";
export const APPOINTMENT = "Appointment";
export const DOCTORS = "doctors";


export const TWILIO_ACC_SID = "ACfd47f24c4d63ce2ca1a983a2abbe5af5";
export const TWILIO_ACC_TOKEN = "848713d87146d4ba7c7a7cb89cc67784";
export const TWILIO_PHONE_NUMBER = "+18507357166";