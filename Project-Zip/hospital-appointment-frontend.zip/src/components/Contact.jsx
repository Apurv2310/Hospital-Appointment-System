import React from 'react';

export function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <h3>Email</h3>
      <p>info@hospital.com</p>
      <h3>Phone</h3>
      <p>+123-456-7890</p>
    </div>
  );
}